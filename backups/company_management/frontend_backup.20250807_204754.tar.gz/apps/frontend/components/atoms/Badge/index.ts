export { Badge, badgeVariants } from './Badge'
export type { BadgeProps } from './Badge' 