import { redirect } from 'next/navigation';

export default function DocsPage() {
  redirect('https://c-and-c-crm-api.onrender.com/docs');
} 